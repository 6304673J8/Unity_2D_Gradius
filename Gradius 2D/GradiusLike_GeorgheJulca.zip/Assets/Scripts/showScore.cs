﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class showScore : MonoBehaviour
{
 
    public Text scoreField;

    public void UpdateScore(int score)
    {
        score = GameManager.Instance.score;
        scoreField.text = score.ToString();
    }
}
